#!/usr/bin/env python3
"""Generate a private progress HTML from one read-only v5 full-metrics snapshot.

The canonical catalog replaces the embedded canonical owner lists in full. This
script never unions a new catalog with the older report directory.
"""
import argparse
import hashlib
import html as html_lib
import json
import re
from datetime import datetime
from pathlib import Path

LANGS = ('cn', 'tw', 'jp', 'ko', 'en')
DEFAULT_BASE = Path('/Users/fan/Repositories/katrain-kiosk-go-kifu/docs/resource/kifu-five-language-progress-2026-10-05.html')
DEFAULT_EXCEPTIONS = Path('/tmp/kifu-firstpass-26-noise-decision-astra-20261011.json')
DEFAULT_EVENT1_STATE = Path('/tmp/kifu-firstpass-continuous-root-20261011/PROD-event1-actual-readonly-20261011.json')


def load_embedded(html):
    text = html.read_text(encoding='utf-8')
    match = re.search(r'(<script id="data" type="application/json">)(.*?)(</script>)', text, re.S)
    if not match:
        raise ValueError(f'HTML has no embedded report JSON: {html}')
    return text, match, json.loads(match.group(2))


def complete_rows(owners, key):
    done = []
    required = set(LANGS)
    for owner in owners:
        names = owner.get('names', [])
        languages = {row.get('lang') for row in names}
        if languages == required:
            done.append({'canonical_name': owner['canonical_name'], key: owner['id'],
                         'languages': ['cn', 'en', 'jp', 'ko', 'tw']})
    return done


def percent(value, denominator):
    return round(100 * value / denominator, 4)


def load_verified_qa_receipt(path, latest, snapshot):
    """Accept only the verified PROD receipt and its hash-pinned apply receipt."""
    receipt = json.loads(path.read_text(encoding='utf-8'))
    if receipt.get('schema') != 'kifu_raw_player_qa_quarantine_receipt_v1' or receipt.get('phase') != 'verify':
        raise ValueError('--qa-receipt must be the QA helper verify receipt')
    if receipt.get('environment') != 'PROD':
        raise ValueError('QA quarantine receipt must be from PROD')
    if receipt.get('latest_batch', {}).get('id') != latest['id'] or latest['id'] != 712:
        raise ValueError('QA receipt and final metrics must both describe applied batch 712')
    if receipt.get('latest_batch', {}).get('status') != 'applied':
        raise ValueError('QA receipt latest batch is not applied')
    if receipt.get('latest_batch', {}).get('bundle_sha256') != latest.get('bundle_sha256'):
        raise ValueError('QA receipt and final metrics batch bundle SHA-256 differ')
    if receipt.get('scope_sha256') != 'c52675ef3c5a4325335735986154bdbdc997f8e6df36504218d07cc113d958a1':
        raise ValueError('unexpected approved QA quarantine scope')
    if receipt.get('source_decision_sha256') != 'cbc2d6b075d4a530b4b79a4724d1d691df1a9481f2a1627a071e1df24b8e6852':
        raise ValueError('unexpected source decision in QA receipt')
    if receipt.get('scope_review_decision_sha256') != '011812c9e85330760c217711eb6081ef65d8cd895fba45f11bb3d5d7911516bb':
        raise ValueError('unexpected scope-review decision in QA receipt')
    try:
        snapshot_time = datetime.fromisoformat(snapshot['captured_at'].replace('Z', '+00:00'))
        verify_time = datetime.fromisoformat(receipt['created_at'].replace('Z', '+00:00'))
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError('QA and metrics snapshots require parseable timestamps') from exc
    if snapshot_time < verify_time:
        raise ValueError('final metrics snapshot predates QA verification')

    apply_path_value = receipt.get('previous_receipt_path')
    apply_sha_expected = receipt.get('previous_receipt_sha256')
    if not apply_path_value or not apply_sha_expected:
        raise ValueError('verify receipt must pin its preceding apply receipt')
    apply_path = Path(apply_path_value)
    if not apply_path.is_absolute():
        apply_path = path.parent / apply_path
    if not apply_path.is_file():
        raise ValueError('hash-pinned QA apply receipt is missing')
    apply_sha = hashlib.sha256(apply_path.read_bytes()).hexdigest()
    if apply_sha != apply_sha_expected:
        raise ValueError('QA apply receipt SHA-256 does not match verify receipt')
    applied = json.loads(apply_path.read_text(encoding='utf-8'))
    if (applied.get('schema') != receipt['schema'] or applied.get('phase') != 'apply'
            or applied.get('environment') != 'PROD'
            or applied.get('scope_sha256') != receipt['scope_sha256']
            or applied.get('source_decision_sha256') != receipt.get('source_decision_sha256')
            or applied.get('scope_review_decision_sha256') != receipt.get('scope_review_decision_sha256')
            or applied.get('latest_batch') != receipt.get('latest_batch')):
        raise ValueError('QA apply receipt does not match its verification receipt')
    before_cells = applied.get('cells')
    after_cells = receipt.get('cells')
    if not isinstance(before_cells, list) or not isinstance(after_cells, list) or len(before_cells) != 121 or len(after_cells) != 121:
        raise ValueError('QA apply and verify receipts must each contain all 121 cells')
    projected = []
    seen = set()
    for before, after in zip(before_cells, after_cells):
        key = (before.get('raw_player_id'), before.get('lang'))
        if key in seen or key != (after.get('raw_player_id'), after.get('lang')):
            raise ValueError('QA cells are duplicated or reordered across apply/verify')
        seen.add(key)
        if any(before.get(k) != after.get(k) for k in ('raw_value', 'raw_player_id', 'lang', 'before_name', 'after_name', 'evidence_sha256', 'owner_sha256')):
            raise ValueError('QA verify cell differs from the hash-pinned apply receipt')
        old_name, new_name = before.get('before_name'), after.get('after_name')
        if not isinstance(old_name, dict) or not isinstance(new_name, dict):
            raise ValueError('QA cell must retain full before/after name images')
        expected = dict(old_name)
        expected['status'] = 'review'
        if old_name.get('status') != 'verified' or new_name != expected:
            raise ValueError('QA cell must change status verified→review and preserve all other fields')
        if (old_name.get('raw_player_id') != key[0] or new_name.get('raw_player_id') != key[0]
                or old_name.get('lang') != key[1] or new_name.get('lang') != key[1]
                or not isinstance(old_name.get('display_name'), str) or not before.get('raw_value')
                or not before.get('evidence_sha256') or not before.get('owner_sha256')):
            raise ValueError('QA cell raw literal, language, unchanged IDs or evidence hashes are incomplete')
        projected.append({
            'raw_player_id': key[0], 'name_id': old_name.get('id'), 'lang': key[1],
            'raw_value': before['raw_value'], 'old_display_name': old_name['display_name'],
            'new_display_name': new_name['display_name'], 'before_status': old_name['status'],
            'status': new_name['status'], 'evidence_id': old_name.get('evidence_id'),
            'evidence_sha256': before['evidence_sha256'], 'owner_sha256': before['owner_sha256'],
            'reason': before.get('reason', 'approved QA quarantine'),
        })
    named_placeholder = [r for r in projected if r['raw_player_id'] == 8325 and r['lang'] in ('cn', 'tw')]
    if len(named_placeholder) != 2 or any(r['old_display_name'] != '棋手' for r in named_placeholder):
        raise ValueError('approved ID 8325 cn/tw placeholder cells do not match the receipt')
    return {
        'phase': 'verify', 'environment': 'PROD', 'verified_at': receipt['created_at'],
        'latest_batch': receipt['latest_batch'], 'scope_sha256': receipt['scope_sha256'],
        'source_decision_sha256': receipt['source_decision_sha256'],
        'scope_review_decision_sha256': receipt['scope_review_decision_sha256'],
        'apply_receipt_path': str(apply_path), 'apply_receipt_sha256': apply_sha,
        'verify_receipt_path': str(path),
        'verify_receipt_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'cell_count': len(projected), 'obvious_fragment_cell_count': len(projected) - len(named_placeholder),
        'placeholder_cells': len(named_placeholder), 'cells': projected,
    }


def render_qa_note(qa):
    if qa is None:
        return ''
    esc = html_lib.escape
    rows = ''.join(
        '<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{} → {}（值与ID保留）</td></tr>'.format(
            esc(str(r['raw_player_id'])), esc(r['raw_value']), esc(r['lang']),
            esc(r['old_display_name']), esc(str(r['name_id'])), esc(str(r['reason'])),
            esc(r['before_status']), esc(r['status']))
        for r in qa['cells'])
    return (
        '<details class="note" id="qa-raw-name-quarantine"><summary>已核实隔离的121个raw-name单元格（状态改为review）</summary>'
        '<p>此处展示PROD第712批后的独立QA verify收据：119个拉丁字母与假名/谚文片段单元格，另有raw_player_id 8325的简体与繁体“棋手”占位名2格。'
        '只将名称状态从verified改为review；原raw值、译名、name ID、raw-player ID、证据和来源记录保留。review状态不符合严格逐槽资格；全局覆盖数字直接取QA之后的实际v5快照，本页不重算或预测指标，也不表示其余单元格均获权威核实。</p>'
        '<p>Verify SHA-256：{}；apply SHA-256：{}。</p>'
        '<div class="table-wrap"><table><thead><tr><th>raw-player ID</th><th>raw value</th><th>语言</th><th>原显示值</th><th>name ID</th><th>隔离理由</th><th>状态变化</th></tr></thead><tbody>{}</tbody></table></div></details>\n'
    ).format(esc(qa['verify_receipt_sha256']), esc(qa['apply_receipt_sha256']), rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--metrics-json', type=Path, required=True,
                        help='Read-only v5 full-metrics output with canonical_catalog')
    parser.add_argument('--base-html', type=Path, default=DEFAULT_BASE)
    parser.add_argument('--exceptions-json', type=Path, default=DEFAULT_EXCEPTIONS)
    parser.add_argument('--event1-state-json', type=Path, default=DEFAULT_EVENT1_STATE,
                        help='Read-only PROD event-1 state used for the E5=84 legacy-name note')
    parser.add_argument('--qa-receipt', type=Path,
                        help='Optional verified PROD raw-name quarantine receipt; requires its hash-pinned apply receipt')
    parser.add_argument('--expected-batch-id', type=int,
                        help='Optional guard, e.g. 711 for the final snapshot')
    parser.add_argument('--output', type=Path,
                        default=Path('/tmp/kifu-progress-final-v5-luna-20261011.html'))
    args = parser.parse_args()
    if not (str(args.output).startswith('/tmp/') or str(args.output).startswith('/private/tmp/')):
        raise ValueError('output must stay under /tmp; tracked report files are not written by this tool')
    if args.output.resolve() == args.base_html.resolve():
        raise ValueError('output must differ from source HTML')

    snapshot = json.loads(args.metrics_json.read_text(encoding='utf-8'))
    if snapshot.get('environment') != 'PROD' or snapshot.get('read_only') is not True:
        raise ValueError('expected a read-only PROD snapshot')
    latest = snapshot.get('latest_batch') or {}
    if latest.get('status') != 'applied' or not isinstance(latest.get('id'), int):
        raise ValueError('latest_batch must identify an applied native batch')
    if args.expected_batch_id is not None and latest['id'] != args.expected_batch_id:
        raise ValueError(f"expected batch {args.expected_batch_id}, got {latest['id']}")
    qa_report = load_verified_qa_receipt(args.qa_receipt, latest, snapshot) if args.qa_receipt else None

    metrics = snapshot['metrics']
    denoms = snapshot['denominators']
    population = snapshot['population']
    catalog = snapshot.get('canonical_catalog')
    if not isinstance(catalog, dict) or not isinstance(catalog.get('player'), list) or not isinstance(catalog.get('event'), list):
        raise ValueError('snapshot lacks v5 canonical_catalog.player/event lists')
    players, events = catalog['player'], catalog['event']
    if (len(players), len(events)) != (denoms['P5'], denoms['E5']):
        raise ValueError('canonical owner lists must match fixed P/E denominators')
    for kind, owners in (('player', players), ('event', events)):
        ids = [row.get('id') for row in owners]
        if any(not isinstance(i, int) for i in ids) or len(ids) != len(set(ids)):
            raise ValueError(f'{kind} catalog owner IDs must be unique integers')
        for owner in owners:
            if not isinstance(owner.get('canonical_name'), str) or not isinstance(owner.get('names'), list):
                raise ValueError(f'{kind} catalog owner lacks canonical_name or names')
            langs = [row.get('lang') for row in owner['names']]
            if len(langs) != len(set(langs)) or any(lang not in LANGS for lang in langs):
                raise ValueError(f'{kind} catalog has duplicate or unsupported locale for owner {owner["id"]}')
            for name in owner['names']:
                if not isinstance(name.get('display_name'), str):
                    raise ValueError(f'{kind} name row lacks display_name')
    players_done = complete_rows(players, 'player_id')
    events_done = complete_rows(events, 'event_id')
    if (len(players_done), len(events_done)) != (metrics['P5'], metrics['E5']):
        raise ValueError('qualified owner counts do not match P5/E5 aggregate metrics')
    if metrics['P5'] > denoms['P5'] or metrics['E5'] > denoms['E5']:
        raise ValueError('qualified owner count exceeds fixed denominator')
    if (denoms['fixedwide'], denoms['strictcomplete']) != (population['albums'], population['albums']):
        raise ValueError('fixedwide/strictcomplete denominators must match actual album population')
    if (denoms['fixedwide'], denoms['strictcomplete'], population['albums']) != (173025, 173025, 173025):
        raise ValueError('the final report must retain the fixed 173025-album denominator')

    exception_doc = json.loads(args.exceptions_json.read_text(encoding='utf-8'))
    if exception_doc.get('decision_id') != 'kifu-firstpass-26-noise-decision-astra-20261011':
        raise ValueError('unexpected source-exception decision record')
    if exception_doc.get('reporting', {}).get('reviewed_exceptions_not_five_language_complete') != 26:
        raise ValueError('expected 26 reviewed exceptions kept outside P5')

    event1_state = json.loads(args.event1_state_json.read_text(encoding='utf-8'))
    if event1_state.get('read_only') is not True or event1_state.get('event', {}).get('id') != 1:
        raise ValueError('event-1 note requires the read-only PROD event-1 snapshot')
    if (event1_state.get('all_refs'), event1_state.get('public_refs')) != (0, 0):
        raise ValueError('event-1 reference counts differ from the supplied current snapshot')
    event1_names = {row.get('lang'): row for row in event1_state.get('names', [])}
    if set(event1_names) != set(LANGS):
        raise ValueError('event-1 legacy note requires all five current name rows')
    legacy_langs = ('cn', 'tw', 'jp', 'en')
    if any(event1_names[lang].get('status') != 'verified'
           or event1_names[lang].get('evidence_id') is not None
           or event1_names[lang].get('revision') is not None for lang in legacy_langs):
        raise ValueError('event-1 legacy name evidence/status differs from supplied snapshot')
    if (event1_names['ko'].get('decision_kind') != 'generated'
            or event1_names['ko'].get('evidence_id') != 128973
            or event1_names['ko'].get('status') != 'verified'):
        raise ValueError('event-1 Korean generated first-pass row differs from supplied snapshot')

    html, match, report = load_embedded(args.base_html)
    old_stats = report['statistics']
    old_catalog = report['catalog']
    # Replace the canonical inventory; never merge with the old report's owner rows.
    old_catalog['players'] = players
    old_catalog['events'] = events
    old_catalog['names']['player'] = [dict(name, owner_id=owner['id'])
        for owner in players for name in owner['names']]
    old_catalog['names']['event'] = [dict(name, owner_id=owner['id'])
        for owner in events for name in owner['names']]
    old_catalog['snapshot_scope'] = (
        f"canonical棋手与赛事目录完全替换为PROD实际目录快照（第{latest['id']}批，{snapshot['captured_at']}）；"
        "不与旧第647批owner清单合并。名称行保留快照原有decision_kind、generation_rule_version、evidence_id等字段；"
        "authoritative_pages按快照原样保留（若本批快照包含）。raw-player/raw-event显示名是独立身份范围，不加入canonical实体分母。"
    )
    old_catalog['raw_event_names_scope'] = (
        old_catalog.get('raw_event_names_scope', 'historic raw-event data')
        + f"；本页canonical指标快照截至第{latest['id']}批，raw-display名称不在canonical实体目录内。"
    )

    fixed_games = population['albums']
    old_stats.update({
        'applied_batch_id': latest['id'],
        'snapshot_batch_id': latest['id'],
        'snapshot_bundle_sha256': latest['bundle_sha256'],
        'snapshot_source': args.metrics_json.name,
        'observed_at': snapshot['captured_at'],
        'games': fixed_games,
        'player_total': denoms['P5'],
        'event_total': denoms['E5'],
        'players_done': players_done,
        'players_done_count': metrics['P5'],
        'players_done_count_pct': percent(metrics['P5'], denoms['P5']),
        'events_done': events_done,
        'events_done_count': metrics['E5'],
        'events_done_count_pct': percent(metrics['E5'], denoms['E5']),
        'entity_or_raw_five_lang_display_games': metrics['fixedwide'],
        'entity_or_raw_five_lang_display_games_pct': percent(metrics['fixedwide'], denoms['fixedwide']),
        'complete_five_lang_display_games': metrics['strictcomplete'],
        'complete_five_lang_display_games_pct': percent(metrics['strictcomplete'], denoms['strictcomplete']),
        'hidden_games': population['list_hidden'],
        'listed_games': population['public_visible'],
        'duplicate_games': population['duplicate'],
        'excluded_from_public_games': population['excluded_from_public'],
        'coverage_method': (
            f"只读PROD完整目录与棋局快照，批次{latest['id']}，采集于{snapshot['captured_at']}。"
            f"P5={metrics['P5']}/{denoms['P5']}；E5={metrics['E5']}/{denoms['E5']}；"
            f"固定宽口径={metrics['fixedwide']}/{denoms['fixedwide']}；"
            f"严格完整={metrics['strictcomplete']}/{denoms['strictcomplete']}。"
            "固定宽口径按规则资格计canonical双方棋手与赛事实体；严格完整要求每盘双方棋手和具体原始赛事标题的所有语言槽均符合资格。"
            "固定宽口径沿用历史canonical实体ID口径；严格完整按每盘实际显示槽逐格判断，合格raw-player/raw-event显示名可计入。因此两项指标独立，严格完整可能高于固定宽口径；raw display名称不充当canonical实体。"
        ),
        'entity_or_raw_five_lang_display_method': (
            '固定宽口径沿用历史canonical实体ID口径；严格完整按逐盘实际显示槽qualification，合格raw-player/raw-event显示名可计入。两项指标统计单位不同且相互独立，严格完整可能高于固定宽口径。'
        ),
    })
    if 'original_player_baseline_total' in old_stats:
        old_stats['players_done_count_original_baseline_pct'] = percent(
            metrics['P5'], old_stats['original_player_baseline_total'])
    report['generated_at'] = snapshot['captured_at']
    report['statistics'] = old_stats
    report['catalog'] = old_catalog
    if qa_report is not None:
        report['raw_player_qa_quarantine'] = qa_report
    data_json = json.dumps(report, ensure_ascii=False, separators=(',', ':'))
    html = html[:match.start()] + match.group(1) + data_json + match.group(3) + html[match.end():]

    # Keep the existing display and method badges; explain that generated rows remain first-pass.
    summary_note = (
        f'<details class="note" id="actual-snapshot-{latest["id"]}"><summary>实际全库快照：第{latest["id"]}批</summary><p>'
        f'PROD只读快照采集于{snapshot["captured_at"]}：棋手首遍五语{metrics["P5"]:,}/{denoms["P5"]} '
        f'（{percent(metrics["P5"], denoms["P5"]):.2f}%），赛事类型首遍五语{metrics["E5"]:,}/{denoms["E5"]} '
        f'（{percent(metrics["E5"], denoms["E5"]):.2f}%）；固定宽口径{metrics["fixedwide"]:,}/{denoms["fixedwide"]} '
        f'（{percent(metrics["fixedwide"], denoms["fixedwide"]):.2f}%），严格完整{metrics["strictcomplete"]:,}/{denoms["strictcomplete"]} '
        f'（{percent(metrics["strictcomplete"], denoms["strictcomplete"]):.2f}%）。canonical目录完整替换自同一快照。'
        '名称行沿用其实际decision和generation方法。“首遍五语齐全”包括既有名称、按规则翻译或转写、以及用户授权生成初译；'
        '表示五个语言槽均有符合当前规则的显示名，不表示每格均经百科/棋院权威核实。权威来源链接仅在快照实际提供页面字段时显示。'
        '固定宽口径沿用canonical实体ID关联口径；严格完整核查逐盘实际显示的各语言槽，可接纳合格raw-player/raw-event显示名。两者单位与资格规则独立，严格完整可能高于固定宽口径，不能将其解读为固定宽口径包含严格完整。Raw-player/raw-event显示名不并入canonical棋手或赛事实体目录。</p></details>\n'
    )
    note_anchor = '<div class="note" id="note"></div>\n'
    if note_anchor not in html:
        raise ValueError('dashboard note anchor missing')
    exception_note = (
        '<details class="note" id="reviewed-source-exceptions-26"><summary>26项已审阅例外保留在五语完成数之外</summary>'
        '<p>依本地决策记录，保留这些owner的ID、原始名称、已有译名和可见性；按标签、组合项、损坏数据或未决名称处理，不把所有项目断定为非人物。'
        '缺少可靠译名时保留原文显示，不把原文回退算作五语完成；不猜字、归并、删除、替换来源或隐藏记录。两条有公开棋局的损坏名称继续原样展示，其余24项的零公开棋局引用只表示优先级较低。</p></details>\n'
    )
    note_block = summary_note
    if metrics['E5'] == 84:
        legacy_event_note = (
            '<details class="note" id="event1-legacy-name-status"><summary>赛事五语计数中的一条legacy记录</summary>'
            '<p>只读PROD状态显示赛事ID 1“吴清源杯”已有简体“吴清源杯”、繁体“吳清源杯”、日文“呉清源杯”和英文“Wu Qingyuan Cup”四条历史verified名称；'
            '这四条均无evidence_id或revision，因此不计入当前五语新流程资格，不能据此表述为本次流程已核实。韩文“우칭위안배”是已合格的生成初译。'
            '同一只读状态下该赛事all_refs=0、public_refs=0；E5仍严格显示v5实际快照中的合格实体数，分母不变。</p></details>\n'
        )
        note_block += legacy_event_note
    if qa_report is not None:
        note_block += render_qa_note(qa_report)
    if 'id="reviewed-source-exceptions-26"' not in html:
        note_block += exception_note
    html = html.replace(note_anchor, note_anchor + note_block, 1)

    # Replace the old dynamic notes with current snapshot-boundary language.
    html = re.sub(r"\$\('note'\)\.textContent='[^\n]*';",
        "$('note').textContent='统计口径：五语为简体、繁体、日文、韩文、英文。统计来自同一只读PROD快照；canonical名单完全替换为该快照中的真实owner目录。原有生成初译与来源决策字段保留，五语资格不等于权威来源认证。';",html,count=1)
    html = re.sub(r"\$\('note'\)\.textContent\+='[^\n]*';",
        "$('note').textContent+=' 固定宽口径按实体ID关联计算；严格完整按实际显示槽计算并允许合格原文译名，因此可高于前者；raw名不并入canonical实体。';",html,count=1)
    # Remove the obsolete live-coverage caveat while preserving the historical value and scope note.
    html = html.replace('当前线上五语展示覆盖尚未按同口径重算。', '')
    # Leave the historical statistics values in embedded JSON unchanged; label their age accurately.
    html = re.sub(r"if\(legacy\)\$\('note'\)\.textContent\+='[^\n]*';",
        "if(legacy)$('note').textContent+=' 其它覆盖细分数字保留为原历史基线，未由本快照重新计算。';",html,count=1)
    html = re.sub(r"\$\('metadata'\)\.textContent='[^\n]*';",
        "$('metadata').textContent='本页是离线快照，采集于 '+generated_at+'（PROD，第'+num(s.snapshot_batch_id)+'批；bundle SHA-256 '+s.snapshot_bundle_sha256+'）。共 '+num(s.games)+' 盘；隐藏 '+num(s.hidden_games)+'，公开 '+num(s.listed_games)+'，重复记录 '+num(s.duplicate_games)+'。';",html,count=1)

    # Make aggregate and row completion labels explicit: qualification includes
    # rule-based translation/transliteration and user-authorized first passes.
    html = html.replace("['棋手五语齐全',s.players_done_count", "['棋手首遍五语齐全',s.players_done_count", 1)
    html = html.replace("['赛事五语齐全',s.events_done_count", "['赛事首遍五语齐全',s.events_done_count", 1)
    html = html.replace("['严格审核全卡覆盖（逐原标题）',s.complete_five_lang_display_games", "['严格完整卡片覆盖（逐原标题）',s.complete_five_lang_display_games", 1)
    html = html.replace('<option value="done">五语齐全</option>',
                        '<option value="done">首遍五语齐全</option>', 1)
    html = html.replace("badge.textContent=r.done?'五语齐全':", "badge.textContent=r.done?'首遍五语齐全':", 1)
    html = html.replace('按关联棋局数量排序；有依据的译名可点击打开来源。',
                        '按目录ID排列；有依据的译名可点击打开来源。', 1)
    old_counts = "const counts=document.createElement('div');counts.className='muted';counts.textContent=num(r.games)+' 盘'+(kind==='player'?' · '+num(r.slots)+' 个棋手槽位':'');tr.children[1].append(counts);"
    if old_counts not in html:
        raise ValueError('expected existing per-owner game-count renderer not found')
    html = html.replace(old_counts,
        "if(Number.isFinite(r.games)){const counts=document.createElement('div');counts.className='muted';counts.textContent=num(r.games)+' 盘'+(kind==='player'?' · '+num(r.slots)+' 个棋手槽位':'');tr.children[1].append(counts);}", 1)

    args.output.write_text(html, encoding='utf-8')
    print(json.dumps({'output': str(args.output), 'batch_id': latest['id'],
        'captured_at': snapshot['captured_at'], 'P5': [metrics['P5'], denoms['P5']],
        'E5': [metrics['E5'], denoms['E5']], 'fixedwide': [metrics['fixedwide'], denoms['fixedwide']],
        'strictcomplete': [metrics['strictcomplete'], denoms['strictcomplete']],
        'canonical_player_rows': len(players), 'canonical_event_rows': len(events),
        'source_exceptions': 26,
        'qa_quarantine_cells': qa_report['cell_count'] if qa_report else None,
        'qa_verify_receipt_sha256': qa_report['verify_receipt_sha256'] if qa_report else None}, ensure_ascii=False, sort_keys=True))

if __name__ == '__main__':
    main()
