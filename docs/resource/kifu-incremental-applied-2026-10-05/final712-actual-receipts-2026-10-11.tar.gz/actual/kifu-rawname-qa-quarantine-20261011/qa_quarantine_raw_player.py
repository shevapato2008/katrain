"""Root-only, exact 121-cell raw-player display quarantine after native batch 712.

No new name batch or evidence is written. Capture/dry-run/verify are read-only.
Apply changes only name.status verified -> review under the native writer locks.
A rollback is an explicit, separately receipted inverse CAS operation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import create_engine, select, update, text
from sqlalchemy.pool import NullPool

from katrain.web.core.models_db import (
    KifuNameBatch, KifuNameChange, KifuNameResearchEvidence,
    KifuRawPlayerName, KifuRawPlayerValue,
)
from katrain.web.kifu.name_batch import _image, _ADVISORY_LOCK_KEY
from katrain.web.kifu.name_candidates import canonical_sha256
from katrain.web.kifu.name_first_pass import VERSION, persisted_eligible, raw_player_scope_live

DATABASES = {"TEST": "katrain_db", "PROD": "katrain_prod_20260725"}
SOURCE_DECISION_SHA256 = "cbc2d6b075d4a530b4b79a4724d1d691df1a9481f2a1627a071e1df24b8e6852"
SCOPE_SHA256 = "c52675ef3c5a4325335735986154bdbdc997f8e6df36504218d07cc113d958a1"
REVIEW_DECISION_SHA256 = "011812c9e85330760c217711eb6081ef65d8cd895fba45f11bb3d5d7911516bb"
TARGET_COUNT = 121


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write_new(path, value):
    with Path(path).open("x") as out:
        json.dump(value, out, ensure_ascii=False, sort_keys=True, indent=2)
        out.write("\n")
        out.flush()
        os.fsync(out.fileno())


def approved_scope(path, expected_sha, decision_path):
    assert expected_sha == SCOPE_SHA256 and file_sha(path) == SCOPE_SHA256, "approved scope file changed"
    assert file_sha(decision_path) == REVIEW_DECISION_SHA256, "Astra decision file changed"
    decision = read(decision_path)
    assert decision["scope"]["sha256"] == SCOPE_SHA256
    assert decision["decision"] == "approve_finite_status_only_quarantine_subject_to_helper_CAS_review"
    scope = read(path)
    assert scope["schema"] == "kifu_raw_player_status_quarantine_scope_v1"
    assert scope["source_review"]["sha256"] == SOURCE_DECISION_SHA256
    assert scope["allowed_mutation"] == {"table": "kifu_raw_player_names", "column": "status",
                                          "from": "verified", "to": "review"}
    cells = scope["cells"]
    assert len(cells) == TARGET_COUNT and scope["counts"]["cells"] == TARGET_COUNT
    keys = [(cell["raw_value"], cell["lang"]) for cell in cells]
    assert len(set(keys)) == TARGET_COUNT
    for cell in cells:
        assert cell["owner_kind"] == "raw_player"
        assert cell["expected_status"] == "verified" and cell["target_status"] == "review"
        assert cell["expected_decision_kind"] == "generated"
        assert cell["expected_generation_rule_version"] == VERSION
        assert cell["raw_value"] and cell["old_display"] and cell["lang"] in {"cn", "tw", "jp", "ko", "en"}
        assert type(cell["prod_owner_id"]) is int and cell["prod_owner_id"] > 0
        assert isinstance(cell["reason"], str) and cell["reason"]
    return scope

def latest_712(conn, env):
    assert conn.scalar(text("SELECT current_database()")) == DATABASES[env], "wrong database"
    row = conn.execute(select(KifuNameBatch.__table__).order_by(KifuNameBatch.id.desc()).limit(1)).mappings().one()
    latest = _image(conn, KifuNameBatch.__table__, row["id"])
    assert latest["id"] == 712 and latest["status"] == "applied", "batch 712 is not the latest applied batch"
    return {"id": latest["id"], "status": latest["status"], "bundle_sha256": latest["bundle_sha256"]}


def batch_members(batch):
    artifact = batch.get("reviewed_artifact") if batch else None
    bundle = artifact.get("bundle") if isinstance(artifact, dict) else None
    assert batch["status"] == "applied" and isinstance(bundle, dict)
    assert canonical_sha256(bundle) == batch["bundle_sha256"]
    return ({canonical_sha256(row) for row in bundle.get("candidates", ())},
            set(artifact.get("research_hashes", ())))


def proof_cell(conn, target, *, lock=False):
    owner_rows = conn.execute(select(KifuRawPlayerValue.__table__).where(
        KifuRawPlayerValue.raw_value == target["raw_value"])).mappings().all()
    assert len(owner_rows) == 1, "raw literal must resolve to exactly one owner"
    owner = _image(conn, KifuRawPlayerValue.__table__, owner_rows[0]["id"])
    if lock:
        conn.execute(select(KifuRawPlayerName.id).where(
            KifuRawPlayerName.raw_player_id == owner["id"],
            KifuRawPlayerName.lang == target["lang"]).with_for_update()).all()
    names = conn.execute(select(KifuRawPlayerName.__table__).where(
        KifuRawPlayerName.raw_player_id == owner["id"],
        KifuRawPlayerName.lang == target["lang"])).mappings().all()
    assert len(names) == 1, "raw-player name must have exactly one owner/lang row"
    name = _image(conn, KifuRawPlayerName.__table__, names[0]["id"])
    assert name["status"] == "verified" and name["display_name"] == target["old_display"]
    assert name["decision_kind"] == "generated" and name["generation_rule_version"] == VERSION
    assert type(name["revision"]) is int and name["evidence_id"] is not None
    evidence = _image(conn, KifuNameResearchEvidence.__table__, name["evidence_id"])
    assert evidence is not None and evidence["raw_player_id"] == owner["id"]
    assert evidence["lang"] == name["lang"] and evidence["revision"] == name["revision"]
    assert evidence["decision_kind"] == "generated" and evidence["generation_rule_version"] == VERSION
    assert evidence["review_status"] == "approved"
    payload = evidence.get("research_payload") or {}
    proof = payload.get("first_pass") if isinstance(payload, dict) else None
    assert isinstance(proof, dict) and type(proof.get("batch_id")) is int
    batch = _image(conn, KifuNameBatch.__table__, proof["batch_id"])
    assert batch is not None
    changes = {}
    for row in conn.execute(select(KifuNameChange.__table__).where(
        KifuNameChange.batch_id == batch["id"],
        ((KifuNameChange.target_table == KifuRawPlayerName.__tablename__)
         & (KifuNameChange.target_row_id == name["id"]))
        | ((KifuNameChange.target_table == KifuNameResearchEvidence.__tablename__)
           & (KifuNameChange.target_row_id == evidence["id"]))
    )).mappings():
        change = _image(conn, KifuNameChange.__table__, row["id"])
        changes[(change["target_table"], change["target_row_id"])] = change
    assert len(changes) == 2
    artifact = batch["reviewed_artifact"]
    bundle = artifact["bundle"]
    declaration = next((item for item in bundle.get("owners", ())
                        if item.get("owner") == {"kind": "raw_player", "id": owner["id"]}), None)
    scope = declaration.get("raw_display_scope") if isinstance(declaration, dict) else None
    assert isinstance(scope, dict) and raw_player_scope_live(conn, scope), "raw scope changed"
    research = payload.get("research")
    source_names = source_evidence = None
    if isinstance(research, dict) and research.get("source_input", {}).get("kind") == "existing_locale":
        source_id = research["source_input"]["name_id"]
        source_name = _image(conn, KifuRawPlayerName.__table__, source_id)
        assert source_name and source_name["evidence_id"]
        source_names = {source_id: source_name}
        source_evidence = {source_name["evidence_id"]:
                           _image(conn, KifuNameResearchEvidence.__table__, source_name["evidence_id"])}
    assert persisted_eligible(name, evidence, "raw_player", owner, batch, changes,
                              source_names=source_names, source_evidence=source_evidence,
                              batch_members=batch_members(batch)), "signed first-pass creation proof failed"
    return {"raw_value": target["raw_value"], "raw_player_id": owner["id"],
            "source_prod_owner_id": target["prod_owner_id"],
            "lang": target["lang"], "reason": target["reason"],
            "before_name": name, "before_name_sha256": canonical_sha256(name),
            "evidence_sha256": canonical_sha256(evidence), "owner_sha256": canonical_sha256(owner),
            "creation_batch_id": batch["id"], "creation_bundle_sha256": batch["bundle_sha256"],
            "creation_changes_sha256": sorted(canonical_sha256(change) for change in changes.values()),
            "raw_scope_sha256": canonical_sha256(scope), "generated_signed_proof": True}


def capture_cells(conn, scope, *, lock=False):
    return [proof_cell(conn, target, lock=lock) for target in scope["cells"]]


def previous(path, expected_sha, phase, env, scope_sha, scope):
    assert path is not None and file_sha(path) == expected_sha, "previous receipt SHA mismatch"
    receipt = read(path)
    assert receipt["schema"] == "kifu_raw_player_qa_quarantine_receipt_v1"
    assert receipt["phase"] == phase and receipt["environment"] == env
    assert receipt["scope_sha256"] == scope_sha and receipt["latest_batch"]["id"] == 712
    assert len(receipt["cells"]) == TARGET_COUNT
    for target, item in zip(scope["cells"], receipt["cells"]):
        assert (item["raw_value"], item["lang"]) == (target["raw_value"], target["lang"])
        assert item["before_name"]["display_name"] == target["old_display"]
        assert item["before_name"]["lang"] == item["lang"]
        assert item["before_name"]["status"] == "verified"
        assert item["before_name"]["decision_kind"] == "generated"
        assert item["before_name"]["generation_rule_version"] == VERSION
        assert item["before_name"]["raw_player_id"] == item["raw_player_id"]
        if phase == "apply":
            assert item["after_name"] == {**item["before_name"], "status": "review"}
    return receipt


def read_phase(engine, env, phase, scope, scope_sha, prev=None):
    with engine.connect() as conn, conn.begin():
        conn.exec_driver_sql("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY")
        latest = latest_712(conn, env)
        if prev is not None:
            assert latest == prev["latest_batch"], "latest native batch changed"
        if phase in {"capture", "dry-run"}:
            cells = capture_cells(conn, scope)
            if prev is not None:
                assert cells == prev["cells"], "live preimages changed after capture"
            return {"latest_batch": latest, "cells": cells}
        assert phase == "verify" and prev is not None
        verified = []
        for item in prev["cells"]:
            after = _image(conn, KifuRawPlayerName.__table__, item["after_name"]["id"])
            evidence = _image(conn, KifuNameResearchEvidence.__table__, item["after_name"]["evidence_id"])
            owner = _image(conn, KifuRawPlayerValue.__table__, item["raw_player_id"])
            assert after == item["after_name"] and after["status"] == "review"
            assert owner["raw_value"] == item["raw_value"]
            assert after["raw_player_id"] == owner["id"] == item["raw_player_id"]
            assert canonical_sha256(evidence) == item["evidence_sha256"]
            assert canonical_sha256(owner) == item["owner_sha256"]
            verified.append(item)
        return {"latest_batch": latest, "cells": verified}


def write_phase(engine, env, phase, scope, prev):
    assert phase in {"apply", "rollback"}
    with engine.begin() as conn:
        assert conn.dialect.name == "postgresql"
        conn.exec_driver_sql("SELECT pg_advisory_xact_lock(%s)", (_ADVISORY_LOCK_KEY,))
        conn.exec_driver_sql("SELECT pg_advisory_xact_lock(%s)", (720220261003,))
        conn.exec_driver_sql(
            "LOCK TABLE kifu_raw_player_values, kifu_raw_player_names, "
            "kifu_name_research_evidence, kifu_name_batches, kifu_name_changes "
            "IN SHARE ROW EXCLUSIVE MODE"
        )
        latest = latest_712(conn, env)
        assert latest == prev["latest_batch"], "latest native batch changed"
        if phase == "apply":
            before = capture_cells(conn, scope, lock=True)
            assert before == prev["cells"], "live preimages changed after dry-run"
            results = []
            for item in before:
                name = item["before_name"]
                stmt = update(KifuRawPlayerName.__table__).where(
                    KifuRawPlayerName.id == name["id"],
                    KifuRawPlayerName.raw_player_id == item["raw_player_id"],
                    KifuRawPlayerName.lang == item["lang"],
                    KifuRawPlayerName.status == "verified",
                    KifuRawPlayerName.display_name == name["display_name"],
                    KifuRawPlayerName.revision == name["revision"],
                    KifuRawPlayerName.evidence_id == name["evidence_id"],
                ).values(status="review")
                assert conn.execute(stmt).rowcount == 1, "status CAS failed"
                after = _image(conn, KifuRawPlayerName.__table__, name["id"])
                expected = {**name, "status": "review"}
                assert after == expected, "status-only after image mismatch"
                results.append({**item, "after_name": after, "after_name_sha256": canonical_sha256(after)})
            return {"latest_batch": latest, "cells": results}
        results = []
        for item in prev["cells"]:
            after = item["after_name"]
            current = _image(conn, KifuRawPlayerName.__table__, after["id"])
            evidence = _image(conn, KifuNameResearchEvidence.__table__, after["evidence_id"])
            owner = _image(conn, KifuRawPlayerValue.__table__, item["raw_player_id"])
            assert current == after and current["status"] == "review"
            assert owner["raw_value"] == item["raw_value"]
            assert current["raw_player_id"] == owner["id"] == item["raw_player_id"]
            assert canonical_sha256(evidence) == item["evidence_sha256"]
            assert canonical_sha256(owner) == item["owner_sha256"]
            stmt = update(KifuRawPlayerName.__table__).where(
                KifuRawPlayerName.id == after["id"], KifuRawPlayerName.raw_player_id == item["raw_player_id"],
                KifuRawPlayerName.lang == item["lang"], KifuRawPlayerName.status == "review",
                KifuRawPlayerName.display_name == after["display_name"],
                KifuRawPlayerName.revision == after["revision"],
                KifuRawPlayerName.evidence_id == after["evidence_id"],
            ).values(status="verified")
            assert conn.execute(stmt).rowcount == 1, "rollback CAS failed"
            restored = _image(conn, KifuRawPlayerName.__table__, after["id"])
            assert restored == item["before_name"], "rollback after image mismatch"
            results.append({**item, "restored_name": restored})
        return {"latest_batch": latest, "cells": results}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("environment", choices=DATABASES)
    parser.add_argument("phase", choices=("capture", "dry-run", "apply", "verify", "rollback"))
    parser.add_argument("--scope", required=True, type=Path)
    parser.add_argument("--scope-sha256", required=True)
    parser.add_argument("--decision", required=True, type=Path)
    parser.add_argument("--previous", type=Path)
    parser.add_argument("--previous-sha256")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    if not __debug__:
        raise RuntimeError("Python optimization is forbidden for quarantine CAS checks")
    assert not args.output.exists(), "receipt already exists"
    scope = approved_scope(args.scope, args.scope_sha256, args.decision)
    prior_phase = {"capture": None, "dry-run": "capture", "apply": "dry-run",
                   "verify": "apply", "rollback": "apply"}[args.phase]
    prev = previous(args.previous, args.previous_sha256, prior_phase, args.environment,
                    args.scope_sha256, scope) if prior_phase else None
    assert (args.previous is None and args.previous_sha256 is None) if prior_phase is None else True
    engine = create_engine(os.environ["KATRAIN_DATABASE_URL"], poolclass=NullPool,
                           isolation_level="REPEATABLE READ" if args.phase in {"capture", "dry-run", "verify"}
                           else "READ COMMITTED",
                           connect_args={"options": "-c default_transaction_read_only=on"}
                           if args.phase in {"capture", "dry-run", "verify"} else {})
    try:
        if args.phase in {"capture", "dry-run", "verify"}:
            output = read_phase(engine, args.environment, args.phase, scope, args.scope_sha256, prev)
        else:
            output = write_phase(engine, args.environment, args.phase, scope, prev)
    finally:
        engine.dispose()
    receipt = {"schema": "kifu_raw_player_qa_quarantine_receipt_v1", "phase": args.phase,
               "environment": args.environment, "scope_sha256": args.scope_sha256,
               "source_decision_sha256": SOURCE_DECISION_SHA256,
               "scope_review_decision_sha256": REVIEW_DECISION_SHA256,
               "previous_receipt_path": str(args.previous) if args.previous else None,
               "previous_receipt_sha256": args.previous_sha256,
               "created_at": datetime.now(timezone.utc).isoformat(), **output}
    write_new(args.output, receipt)
    print(json.dumps({"environment": args.environment, "phase": args.phase,
                      "receipt": str(args.output), "receipt_sha256": file_sha(args.output),
                      "latest_batch_id": receipt["latest_batch"]["id"],
                      "cells": len(receipt["cells"]), "status": "ready"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
