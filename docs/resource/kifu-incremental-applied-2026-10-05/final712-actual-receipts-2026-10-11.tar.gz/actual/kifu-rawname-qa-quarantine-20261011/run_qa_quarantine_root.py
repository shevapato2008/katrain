"""Root-only transport for one approved 121-cell QA quarantine phase."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shlex
import subprocess
from pathlib import Path

D = Path('/tmp/kifu-rawname-qa-quarantine-20261011')
CACHE = Path('/tmp/kifu-importer-context-cache-20261011')
FORMAL = Path('/tmp/kifu-formal-seven-firstpass-deploy-sol-20261011')
HOSTS = {
    'TEST': ('home-ubuntu', 'katrain-web', '/tmp/kifu-root-test-oct10.sock'),
    'PROD': ('ucloud-v100', 'katrain-ucloud-katrain-web-1', '/tmp/kifu-root-prod-oct9.sock'),
}
PINNED = {
    'qa_quarantine_raw_player.py': '5cb38318108e38ea348011bd1931ef47585b92e5ffd9ab1e360de60ea927db7d',
    'scope-v2.json': 'c52675ef3c5a4325335735986154bdbdc997f8e6df36504218d07cc113d958a1',
    'decision-v2.json': '011812c9e85330760c217711eb6081ef65d8cd895fba45f11bb3d5d7911516bb',
    'astra-helper-review.json': 'ddba2710aabafd09943da1ef74c8ca7d7f25691d77421365222c02a46f764b65',
}
PREVIOUS = {'capture': None, 'dry-run': 'capture', 'apply': 'dry-run', 'verify': 'apply'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def ssh(host, socket, command, data=None):
    p = subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ControlPath=' + socket,
                        host, command], input=data, capture_output=True)
    if p.returncode:
        raise RuntimeError('QA remote operation failed; private output withheld')
    return p.stdout


def scp(host, socket, source, target):
    p = subprocess.run(['scp', '-q', '-o', 'ControlPath=' + socket,
                        source, target], capture_output=True)
    if p.returncode:
        raise RuntimeError('QA receipt/file transfer failed; private output withheld')


def write_new(path, value):
    data = (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    with open(path, 'xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('environment', choices=HOSTS)
    ap.add_argument('phase', choices=PREVIOUS)
    ap.add_argument('--native-verify', required=True, type=Path)
    args = ap.parse_args()
    env, phase = args.environment, args.phase
    host, web, socket = HOSTS[env]
    for name, digest in PINNED.items():
        assert sha(D / name) == digest, f'{name} changed'
    review = read(D / 'astra-helper-review.json')
    assert review['decision'] == 'approve_helper_for_root_bound_execution'
    assert review['helper']['sha256'] == PINNED['qa_quarantine_raw_player.py']
    assert review['scope']['sha256'] == PINNED['scope-v2.json']
    assert review['policy_decision']['sha256'] == PINNED['decision-v2.json']
    native = read(args.native_verify)
    assert native['phase'] == 'verify' and native['status'] == 'verified'
    assert native['environment'] == env and native['batch_id'] == 712
    assert native['latest_after'] == {'id': 712, 'status': 'applied',
                                      'bundle_sha256': native['bundle_sha256']}
    native_sha = sha(args.native_verify)
    build_path = CACHE / f'{env}-importer/build-result-actual.json'
    build = read(build_path)
    formal_path = FORMAL / f'{env}-importer/build-result-actual.json'
    formal = read(formal_path)
    assert build['environment'] == env and build['status'] == 'built_verified'
    assert build['base_formalevent_image_id'] == formal['formalevent_image_id']
    assert build['base_formalevent_receipt_sha256'] == sha(formal_path)
    assert build['patched_leaves'] == {
        'katrain/web/kifu/name_batch.py': 'de7a2c43f87ec6dde869eba957c67ba33ef9190045a88e50c89f3f60a03dda20',
        'katrain/web/kifu/name_candidates.py': '6324acd90a80b85b9857be53ff715810abae42be5d1abf155fa25deba5700ac4',
    }
    assert build['expected_files'] == formal['expected_files'] | build['patched_leaves']
    image, importer_files = build['cached_image_id'], build['expected_files']
    assert isinstance(image, str) and image.startswith('sha256:') and len(image) == 71
    deployment_path = FORMAL / f'{env}-web/deployment-verified-actual.json'
    deployment = read(deployment_path)
    plan = read(FORMAL / f'{env}-web/plan.json')
    assert deployment['environment'] == env and deployment['phase'] == 'verified'
    assert deployment['runtime_files'] == plan['expected_runtime_files']
    web_files = deployment['runtime_files']
    actual_dir = D / 'actual' / env
    actual_dir.mkdir(parents=True, exist_ok=True)
    output = actual_dir / f'{phase}-receipt.json'
    intent_path = actual_dir / f'{phase}-intent.json'
    assert not output.exists() and not intent_path.exists(), 'phase already attempted'
    prior_phase = PREVIOUS[phase]
    prior_path = actual_dir / f'{prior_phase}-receipt.json' if prior_phase else None
    prior_sha = None
    if prior_path:
        assert prior_path.is_file(), 'previous phase receipt missing'
        prior = read(prior_path)
        assert prior['schema'] == 'kifu_raw_player_qa_quarantine_receipt_v1'
        assert prior['environment'] == env and prior['phase'] == prior_phase
        assert prior['latest_batch']['id'] == 712
        prior_sha = sha(prior_path)
        prev_intent = read(actual_dir / f'{prior_phase}-intent.json')
        assert prev_intent['native_verify_sha256'] == native_sha
    ssh(host, socket, 'mkdir -p ' + shlex.quote(str(actual_dir)))
    for name, digest in PINNED.items():
        path = D / name
        remote = str(path)
        existing = ssh(host, socket, 'if test -f ' + shlex.quote(remote)
                       + '; then sha256sum ' + shlex.quote(remote) + '; fi').decode().strip()
        if existing:
            assert existing.split()[0] == digest, f'remote {name} changed'
        else:
            scp(host, socket, str(path), f'{host}:{remote}')
            assert ssh(host, socket, 'sha256sum ' + shlex.quote(remote)).decode().split()[0] == digest
    if prior_path:
        assert ssh(host, socket, 'sha256sum ' + shlex.quote(str(prior_path))).decode().split()[0] == prior_sha
    assert not ssh(host, socket, 'if test -e ' + shlex.quote(str(output))
                   + '; then printf EXISTS; fi'), 'remote output already exists'
    intent = {'schema': 'kifu_raw_player_qa_transport_intent_v1', 'environment': env, 'phase': phase,
              'native_verify_path': str(args.native_verify), 'native_verify_sha256': native_sha,
              'helper_sha256': PINNED['qa_quarantine_raw_player.py'],
              'scope_sha256': PINNED['scope-v2.json'],
              'decision_sha256': PINNED['decision-v2.json'],
              'review_sha256': PINNED['astra-helper-review.json'],
              'previous_receipt_path': str(prior_path) if prior_path else None,
              'previous_receipt_sha256': prior_sha,
              'cached_image_id': image, 'cached_build_receipt_sha256': sha(build_path),
              'web_deployment_receipt_sha256': sha(deployment_path),
              'output_path': str(output)}
    write_new(intent_path, intent)
    remote_code = f'''import hashlib,json,subprocess,sys
d={str(D)!r};web={web!r};image={image!r};importer_files={importer_files!r}
files={web_files!r};container_id={deployment['container']!r};web_image={deployment['image']!r}
env={env!r};phase={phase!r};previous={str(prior_path) if prior_path else None!r}
previous_sha={prior_sha!r};output={str(output)!r};pinned={PINNED!r}
def digest(path):return hashlib.sha256(open(path,'rb').read()).hexdigest()
assert subprocess.check_output(['docker','image','inspect',image,'--format','{{{{.Id}}}}'],text=True).strip()==image
check="import hashlib,json;from pathlib import Path;files="+repr(importer_files)+";print(json.dumps({{p:hashlib.sha256(Path('/app',p).read_bytes()).hexdigest() if Path('/app',p).is_file() else None for p in files}}))"
icmd=['docker','run','--rm','--read-only','--network','none','--entrypoint','python',image,'-B','-c',check]
assert json.loads(subprocess.check_output(icmd,text=True))==importer_files
before=json.loads(subprocess.check_output(['docker','inspect',web],text=True))[0]
assert before['State']['Running'] is True and before['Id']==container_id and before['Image']==web_image
webcheck="import hashlib,json;from pathlib import Path;files="+repr(files)+";print(json.dumps({{p:hashlib.sha256(Path('/app',p).read_bytes()).hexdigest() if Path('/app',p).is_file() else None for p in files}}))"
assert json.loads(subprocess.check_output(['docker','exec',web,'python','-B','-c',webcheck],text=True))==files
assert all(digest(d+'/'+name)==sha for name,sha in pinned.items())
assert previous is None or digest(previous)==previous_sha
assert not __import__('os').path.exists(output)
urls=[s.split('=',1)[1] for s in before['Config']['Env'] if s.startswith('KATRAIN_DATABASE_URL=')]
assert len(urls)==1
command=['docker','run','--rm','--read-only','--user','0:0','-i','--network','container:'+web,
 '--env-file','/dev/stdin','-v',d+':'+d+':rw','-w','/app','--entrypoint','python',image,
 d+'/qa_quarantine_raw_player.py',env,phase,'--scope',d+'/scope-v2.json',
 '--scope-sha256',pinned['scope-v2.json'],'--decision',d+'/decision-v2.json',
 '--output',output]
if previous is not None:command+=['--previous',previous,'--previous-sha256',previous_sha]
run=subprocess.run(command,input=('KATRAIN_DATABASE_URL='+urls[0]+'\\n').encode(),capture_output=True)
if run.returncode:raise RuntimeError('QA helper failed; private output withheld')
result=json.loads(run.stdout)
assert result['environment']==env and result['phase']==phase and result['receipt']==output
assert result['latest_batch_id']==712 and result['cells']==121 and result['status']=='ready'
assert digest(output)==result['receipt_sha256']
after=json.loads(subprocess.check_output(['docker','inspect',web],text=True))[0]
assert after['Id']==before['Id'] and after['Image']==before['Image']
assert json.loads(subprocess.check_output(['docker','exec',web,'python','-B','-c',webcheck],text=True))==files
assert json.loads(subprocess.check_output(icmd,text=True))==importer_files
assert all(digest(d+'/'+name)==sha for name,sha in pinned.items())
sys.stdout.write(json.dumps(result))
'''
    compile(remote_code, 'QA transport', 'exec')
    result = json.loads(ssh(host, socket, 'python3 -', remote_code.encode()))
    assert result['environment'] == env and result['phase'] == phase
    assert result['receipt'] == str(output) and result['latest_batch_id'] == 712
    assert result['cells'] == 121 and result['status'] == 'ready'
    remote_sha = ssh(host, socket, 'sha256sum ' + shlex.quote(str(output))).decode().split()[0]
    assert remote_sha == result['receipt_sha256']
    temporary = actual_dir / f'.{phase}-receipt.download'
    assert not temporary.exists()
    scp(host, socket, f'{host}:{output}', str(temporary))
    assert sha(temporary) == remote_sha
    with open(temporary, 'rb') as stream:
        os.fsync(stream.fileno())
    os.link(temporary, output)
    temporary.unlink()
    receipt = read(output)
    assert receipt['schema'] == 'kifu_raw_player_qa_quarantine_receipt_v1'
    assert receipt['environment'] == env and receipt['phase'] == phase
    assert receipt['latest_batch']['id'] == 712 and len(receipt['cells']) == 121
    print(json.dumps({'environment': env, 'phase': phase, 'receipt': str(output),
                      'sha256': sha(output), 'cells': 121, 'latest_batch_id': 712}, sort_keys=True))


if __name__ == '__main__':
    main()
