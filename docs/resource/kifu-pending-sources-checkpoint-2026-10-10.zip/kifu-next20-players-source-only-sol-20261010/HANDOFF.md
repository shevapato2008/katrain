# Next 20 player names: source-only handoff

Unsigned candidate: `next20-main5-source-only-unsigned.json`.

- 20 distinct PROD queue player IDs, five language display proposals each. Legacy queue game-count sum: 1,389; this is not a deduplicated physical-game count or current DB measure.
- 29 distinct proposed source-registry URLs, 32 candidate-source links. Every retained body path, SHA-256 and cited visible excerpt was checked against the local body. Source roles are identified, while registry IDs are proposals for later native assembly.
- Four current-queue holds excluded: 4538, 6190, 4692 (possible duplicates) and 5563 (name/identity reading unresolved).
- CN preserves old canonical names. TW script changes are marked as conversions; no Taiwan publication is inferred. Japanese official profile names from Nihon Ki-in retain U+3000 spaces.
- 117: CN 尹炫皙 versus KBA Hanja 尹炫晳. 827: CN 俞旿成 versus KBA Hanja 兪旿成. Both differences are explicit in the candidate rows; no identity merge is proposed. The JA forms for these Korean players are script carryovers from the KBA Hanja, not local Japanese attestations.
- 4804 JA is Chinese Hanzi carryover without a Japanese local page. 5569 KO is generated from published CWI Latin `Tanaka Fujio`, not from an uncaptured kana reading. Generated Korean and English names cite their actual reading or Latin basis and remain subject to normative transliteration review.
- No current TEST/PROD catalog capture, SQL, native assembly, source approval, or product registry change. Root can bind these candidates after the seven identity merges and choose existing supported equivalent source URLs where needed.
