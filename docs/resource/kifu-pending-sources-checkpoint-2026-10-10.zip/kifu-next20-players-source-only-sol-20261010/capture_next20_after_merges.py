"""Capture twenty existing player owners and complete linked physical preimages, read only."""

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path

from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session
from sqlalchemy.pool import NullPool

from katrain.web.core.models_db import KifuPlayerName
from katrain.web.kifu.identity import _approved_names, _qualified_name_rows
from katrain.web.kifu.name_batch import _catalog_sha, _snapshot_parts
from katrain.web.kifu.name_evidence import registry_sha256

DATABASES = {'TEST': 'katrain_db', 'PROD': 'katrain_prod_20260725'}
SOURCE = Path('/work/next20-main5-source-only-unsigned.json')
REGISTRY = Path('/work/registry-selected-377.json')
SOURCE_SHA = '4535ae03b592b245802b6db7a87aebe7124cdc8de27950affcab6bf9f719a6f1'
REGISTRY_SHA = '611561f7b283302de72abcea74eef364f436b2a46685e6fa962214a1cd766415'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def serial(value):
    return json.loads(json.dumps(value, ensure_ascii=False,
        default=lambda item: item.isoformat() if hasattr(item, 'isoformat') else str(item)))


def rows(conn, sql, params=None):
    return [serial(dict(row)) for row in conn.execute(text(sql), params or {}).mappings()]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--environment', choices=DATABASES, required=True)
    parser.add_argument('--native-manifest', type=Path, required=True)
    parser.add_argument('--expected-latest-id', type=int, required=True)
    parser.add_argument('--expected-latest-bundle-sha', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    assert sha(SOURCE) == SOURCE_SHA
    source = json.loads(SOURCE.read_bytes())
    selected = {row['prod_player_id']: row for row in source['candidates']}
    assert len(selected) == 20 and source['scope']['ready_people'] == 20
    assert sha(REGISTRY) and registry_sha256(json.loads(REGISTRY.read_bytes())) == REGISTRY_SHA
    manifest = json.loads(args.native_manifest.read_bytes())
    assert manifest['environment'] == args.environment and manifest['kind'] == 'importer'
    image_id = manifest['r18_image_id']
    assert all(sha(Path('/app') / path) == digest for path, digest in manifest['expected_files'].items())
    engine = create_engine(os.environ['KATRAIN_DATABASE_URL'], poolclass=NullPool,
        isolation_level='REPEATABLE READ', connect_args={'options': '-c default_transaction_read_only=on'})
    try:
        with engine.connect() as conn, conn.begin():
            conn.exec_driver_sql('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY')
            assert conn.dialect.name == 'postgresql'
            assert conn.scalar(text('SHOW transaction_read_only')) == 'on'
            assert conn.scalar(text('SELECT current_database()')) == DATABASES[args.environment]
            latest = rows(conn, 'SELECT id,status,bundle_sha256 FROM kifu_name_batches ORDER BY id DESC LIMIT 1')[0]
            assert latest == {'id': args.expected_latest_id, 'status': 'applied',
                'bundle_sha256': args.expected_latest_bundle_sha}, latest
            inventory_sha, selection, base_sha = _snapshot_parts(conn, inventory_format=4)
            catalog_sha = _catalog_sha(conn)
            registry_row = rows(conn, 'SELECT * FROM kifu_name_source_registry WHERE id=377')[0]
            assert registry_row['sha256'] == REGISTRY_SHA
            assert registry_sha256(registry_row['registry']) == REGISTRY_SHA
            owners, discovery, mapping = {}, {}, {}
            with Session(bind=conn) as session:
                for prod_id, item in selected.items():
                    canonical = item['old_canonical_cn']
                    possible = rows(conn, '''SELECT p.* FROM kifu_players p WHERE
                        p.canonical_name=:name OR p.id IN
                        (SELECT player_id FROM kifu_player_names WHERE display_name=:name) OR p.id IN
                        (SELECT black_player_id FROM kifu_albums WHERE player_black=:name AND black_player_id IS NOT NULL) OR p.id IN
                        (SELECT white_player_id FROM kifu_albums WHERE player_white=:name AND white_player_id IS NOT NULL)
                        ORDER BY p.id''', {'name': canonical})
                    if args.environment == 'PROD':
                        exact = rows(conn, 'SELECT * FROM kifu_players WHERE id=:id', {'id': prod_id})
                        assert len(exact) == 1 and exact[0]['canonical_name'] == canonical, (prod_id, exact)
                        if not any(row['id'] == prod_id for row in possible):
                            possible.append(exact[0])
                    choices = []
                    for owner in possible:
                        owner_id = owner['id']
                        count = conn.scalar(text('SELECT COUNT(*) FROM kifu_albums WHERE black_player_id=:id OR white_player_id=:id'), {'id': owner_id})
                        qualified = _qualified_name_rows(session,
                            _approved_names(session, KifuPlayerName, 'player_id', {owner_id}),
                            KifuPlayerName, 'player_id')
                        qnames = {name.lang: {'display_name': name.display_name,
                            'name_id': name.id, 'evidence_id': evidence.id}
                            for name, evidence in qualified}
                        choices.append({'owner_id': owner_id, 'canonical_name': owner['canonical_name'],
                            'linked_album_count': count, 'qualified_names': qnames})
                    discovery[str(prod_id)] = choices
                    if args.environment == 'PROD':
                        chosen = next(row for row in choices if row['owner_id'] == prod_id)
                    else:
                        exact = [row for row in choices if row['canonical_name'] == canonical
                            and row['linked_album_count'] == item['historical_games']]
                        if len(exact) != 1:
                            exact = [row for row in choices if row['canonical_name'] == canonical
                                and row['linked_album_count'] > 0]
                        assert len(exact) == 1, (prod_id, choices)
                        chosen = exact[0]
                    owner_id = chosen['owner_id']
                    assert owner_id not in mapping.values(), (prod_id, owner_id)
                    assert chosen['linked_album_count'] > 0, (prod_id, chosen)
                    mapping[prod_id] = owner_id
                    owner = next(row for row in possible if row['id'] == owner_id)
                    names = rows(conn, 'SELECT * FROM kifu_player_names WHERE player_id=:id ORDER BY id', {'id': owner_id})
                    evidence = rows(conn, 'SELECT * FROM kifu_name_research_evidence WHERE player_id=:id ORDER BY id', {'id': owner_id})
                    aliases = rows(conn, 'SELECT * FROM kifu_player_aliases WHERE player_id=:id ORDER BY id', {'id': owner_id})
                    albums = []
                    for raw in conn.execute(text('SELECT * FROM kifu_albums WHERE black_player_id=:id OR white_player_id=:id ORDER BY id'), {'id': owner_id}).mappings():
                        row = dict(raw)
                        sgf = row['sgf_content']
                        assert isinstance(sgf, str)
                        row['sgf_utf8_sha256'] = hashlib.sha256(sgf.encode('utf-8')).hexdigest()
                        albums.append(serial(row))
                    assert len(albums) == chosen['linked_album_count']
                    owners[str(prod_id)] = {'actual_owner_id': owner_id,
                        'owner_preimage': owner, 'name_preimages': names,
                        'evidence_preimages': evidence, 'alias_preimages': aliases,
                        'albums_full_physical_with_sgf': albums,
                        'qualified_existing': chosen['qualified_names'],
                        'cn_legacy_rows': [row for row in names if row['lang'] == 'cn'],
                        'historical_queue_games': item['historical_games'],
                        'actual_linked_games': len(albums)}
            album_ids = sorted({row['id'] for x in owners.values() for row in x['albums_full_physical_with_sgf']})
            album_sources = rows(conn, 'SELECT * FROM kifu_album_sources WHERE album_id=ANY(:ids) ORDER BY id', {'ids': album_ids})
            source_ids = sorted({row['source_id'] for row in album_sources})
            physical_sources = rows(conn, 'SELECT * FROM kifu_sources WHERE id=ANY(:ids) ORDER BY id', {'ids': source_ids})
            result = {'kind':'next20_player_after_merges_readonly_capture',
                'environment':args.environment, 'read_only':True,
                'captured_at':datetime.now(timezone.utc).isoformat(),
                'image_id':image_id, 'native_manifest_sha256':sha(args.native_manifest),
                'source_packet_sha256':SOURCE_SHA, 'registry_file_sha256':sha(REGISTRY),
                'latest_batch':latest, 'catalog_sha256':catalog_sha,
                'inventory_format':4, 'inventory_sha256':inventory_sha,
                'base_sha256':base_sha, 'selection_supplement':selection,
                'selected_language_registry':registry_row,
                'prod_to_actual_owner_ids':{str(k):v for k,v in mapping.items()},
                'owner_discovery_candidates':discovery, 'owners':owners,
                'unique_album_count':len(album_ids), 'album_sources':album_sources,
                'sources':physical_sources}
            payload = json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(',',':')).encode()
            args.output.write_bytes(gzip.compress(payload,mtime=0))
            print(json.dumps({'status':result['kind'], 'environment':args.environment,
                'latest_batch':latest['id'], 'owners':len(owners),
                'unique_albums':len(album_ids),
                'actual_linked_game_sum':sum(x['actual_linked_games'] for x in owners.values()),
                'qualified_languages':{k:sorted(v['qualified_existing']) for k,v in owners.items()},
                'capture_sha256':sha(args.output)}, ensure_ascii=False))
    finally:
        engine.dispose()


if __name__ == '__main__':
    main()
