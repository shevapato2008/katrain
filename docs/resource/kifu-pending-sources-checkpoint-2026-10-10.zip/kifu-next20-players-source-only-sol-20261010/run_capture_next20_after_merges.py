"""Stage and run the next-20 read-only R18 owner capture after root supplies actual latest batch."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess

D = Path(__file__).resolve().parent
R18 = Path('/tmp/kifu-event-collision-r18-native-20261010')
REGISTRY = Path('/tmp/kifu-next-four-ja-ko-20261010/registry-selected-377.json')
REMOTE_DIR = '/tmp/kifu-next20-player-native-aftermerge-sol-20261010'
HOSTS = {'TEST':('home-ubuntu','katrain-web','/tmp/kifu-root-test-oct10.sock'),
         'PROD':('ucloud-v100','katrain-ucloud-katrain-web-1','/tmp/kifu-root-prod-oct9.sock')}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('environment',choices=HOSTS)
    parser.add_argument('--expected-latest-id',type=int,required=True)
    parser.add_argument('--expected-latest-bundle-sha',required=True)
    args = parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{64}',args.expected_latest_bundle_sha)
    host,web,control=HOSTS[args.environment]
    opts=['-o','ControlPath='+control]
    build=R18/f'{args.environment}-importer/build-result-actual.json'
    manifest=json.loads(build.read_bytes())
    assert manifest['environment']==args.environment and manifest['kind']=='importer'
    image=manifest['r18_image_id']
    name=f'{args.environment}-next20-after-batch{args.expected_latest_id}-capture-actual.json.gz'
    out=D/name
    assert not out.exists(),out
    script=D/'capture_next20_after_merges.py'
    assets=[(script,f'{REMOTE_DIR}/capture_next20_after_merges.py'),
            (D/'next20-main5-source-only-unsigned.json',f'{REMOTE_DIR}/next20-main5-source-only-unsigned.json'),
            (REGISTRY,f'{REMOTE_DIR}/registry-selected-377.json'),
            (build,f'{REMOTE_DIR}/r18-build-result-actual.json')]
    subprocess.run(['ssh',*opts,host,f'mkdir -p {REMOTE_DIR}/captures'],check=True)
    for local,remote in assets:
        old=subprocess.run(['ssh',*opts,host,f'if test -f {shlex.quote(remote)}; then sha256sum {shlex.quote(remote)}; fi'],capture_output=True,text=True,check=True).stdout.strip()
        if old:
            assert old.split()[0]==sha(local),(remote,'remote staged hash changed')
        else:
            subprocess.run(['scp','-q',*opts,str(local),f'{host}:{remote}'],check=True)
    code=f'''import hashlib,json,re,subprocess
from pathlib import Path
D=Path({REMOTE_DIR!r}); env={args.environment!r}; web={web!r}; image={image!r}
expected_id={args.expected_latest_id!r}; expected_bundle={args.expected_latest_bundle_sha!r}; out_name={name!r}
assert hashlib.sha256((D/'capture_next20_after_merges.py').read_bytes()).hexdigest()=={sha(script)!r}
assert subprocess.check_output(['docker','image','inspect',image,'--format','{{{{.Id}}}}'],text=True).strip()==image
meta=json.loads(subprocess.check_output(['docker','inspect',web],text=True))[0]
assert meta['State']['Running'] is True
urls=[x.split('=',1)[1] for x in meta['Config']['Env'] if x.startswith('KATRAIN_DATABASE_URL=')]
assert len(urls)==1
out=D/'captures'/out_name; assert not out.exists()
cmd=['docker','run','--rm','--read-only','--user','0:0','-i','--network','container:'+web,
 '--env-file','/dev/stdin','-v',str(D)+':/work:ro','-v',str(D/'captures')+':/out:rw',
 '-w','/app','--entrypoint','python',image,'/work/capture_next20_after_merges.py',
 '--environment',env,'--native-manifest','/work/r18-build-result-actual.json',
 '--expected-latest-id',str(expected_id),'--expected-latest-bundle-sha',expected_bundle,
 '--output','/out/'+out_name]
p=subprocess.run(cmd,input=('KATRAIN_DATABASE_URL='+urls[0]+'\\n').encode(),capture_output=True)
if p.returncode:
 raise RuntimeError(re.sub(r'[A-Za-z][A-Za-z0-9+.-]*://\\S+','[redacted URL]',p.stderr.decode(errors='replace')[-5000:]))
result=json.loads(p.stdout); assert result['environment']==env and result['latest_batch']==expected_id
print(json.dumps({{'environment':env,'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
 'owners':result['owners'],'unique_albums':result['unique_albums'],'qualified_languages':result['qualified_languages']}},ensure_ascii=False))
'''
    p=subprocess.run(['ssh',*opts,host,'python3 -'],input=code.encode(),capture_output=True)
    if p.returncode:
        raise RuntimeError(re.sub(r'[A-Za-z][A-Za-z0-9+.-]*://\S+','[redacted URL]',p.stderr.decode(errors='replace')[-5000:]))
    receipt=json.loads(p.stdout)
    subprocess.run(['scp','-q',*opts,f'{host}:{REMOTE_DIR}/captures/{name}',str(out)],check=True)
    assert sha(out)==receipt['sha256']
    print(json.dumps(receipt,ensure_ascii=False))


if __name__=='__main__':
    main()
